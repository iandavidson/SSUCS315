Ian Davidson
Lab03
README.txt
Spring 2017

       The file linearlyNestedParentheses_rec.cpp works fine. The function, isList() breaks into cases with corresponding
       recursive calls, determined if the current Token being looked at (sitting in variable "token") is Curly, Bracket or
       Paren.    
